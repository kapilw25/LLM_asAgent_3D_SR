"""
Generate augmented V-JEPA embeddings for True Overlap@K measurement.
GPU-only. Produces overlap_augA.npy and overlap_augB.npy from same clips.

USAGE:
    python -u src/m05c_true_overlap.py --SANITY 2>&1 | tee logs/m05c_overlap_sanity.log
    python -u src/m05c_true_overlap.py --POC --subset data/subset_10k_local/subset_10k.json --local-data data/subset_10k_local 2>&1 | tee logs/m05c_overlap_poc.log
    python -u src/m05c_true_overlap.py --FULL --local-data data/full_local 2>&1 | tee logs/m05c_overlap_full.log
"""
import argparse
import os
import queue
import shutil
import sys
import tempfile
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import numpy as np
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).parent))
from utils.config import (
    VJEPA_FRAMES_PER_CLIP, check_gpu, check_output_exists,
    load_subset, add_subset_arg, add_local_data_arg, get_module_output_dir,
    get_sanity_clip_limit, get_total_clips, get_pipeline_config,
    verify_npy_matches_subset,
)
from utils.data_download import ensure_local_data, iter_clips_parallel
from utils.gpu_batch import compute_batch_sizes, add_gpu_mem_arg, cuda_cleanup, cleanup_temp, AdaptiveBatchSizer
from utils.cgroup_monitor import print_cgroup_header, start_oom_watchdog
from utils.wandb_utils import add_wandb_args, init_wandb, log_metrics, log_artifact, finish_wandb

from utils.video_io import get_clip_key, create_stream, decode_video_bytes
from m05_vjepa_embed import get_batch_embeddings

_pcfg_stream = get_pipeline_config()
DECODE_WORKERS = _pcfg_stream["streaming"]["decode_workers_embed"]
MAX_STREAM_RETRIES = _pcfg_stream["streaming"]["max_retries"]
CHECKPOINT_EVERY = _pcfg_stream["streaming"]["checkpoint_every"]
PREFETCH_QUEUE_SIZE = _pcfg_stream["streaming"]["prefetch_queue_embed"]

_create_stream = create_stream

import torch
import torchvision.transforms as T
import torchvision.transforms.functional as TF
from utils.data_paths import artifact  # iter18 W4: canonical artifact names (pipeline.yaml)

# iter18 W7 (PLR2004): semantic named constants.
_FLIP_P = 0.5      # horizontal-flip probability (overlap-aug recipe)
_HUE_EPS = 0.01    # |hue| below this = identity jitter, skip


# ── Augmentation Transforms (BYOL/DINO protocol) ─────────────────────

def _augment_clip_consistent(video_tensor: torch.Tensor, view: str,
                              seed: int) -> torch.Tensor:
    """Vectorized BYOL/DINO augmentation on full (T,C,H,W) tensor.

    Replaces per-frame loop with batch tensor ops (64x fewer kernel launches).
    """
    T_frames, C, H, W = video_tensor.shape
    rng = torch.Generator()
    rng.manual_seed(seed)

    if view == "A":
        # Large crop (0.4-1.0 of area)
        i, j, h, w = T.RandomResizedCrop.get_params(
            video_tensor[0], scale=(0.4, 1.0), ratio=(0.75, 1.33))
        do_flip = torch.rand(1, generator=rng).item() < _FLIP_P
        # Color jitter params (fixed for all frames)
        brightness = 1.0 + (torch.rand(1, generator=rng).item() - 0.5) * 0.8
        contrast = 1.0 + (torch.rand(1, generator=rng).item() - 0.5) * 0.8
        saturation = 1.0 + (torch.rand(1, generator=rng).item() - 0.5) * 0.4
        hue = (torch.rand(1, generator=rng).item() - 0.5) * 0.2
    else:
        # Small crop (0.2-0.6 of area)
        i, j, h, w = T.RandomResizedCrop.get_params(
            video_tensor[0], scale=(0.2, 0.6), ratio=(0.75, 1.33))
        do_flip = torch.rand(1, generator=rng).item() < _FLIP_P

    # ── Vectorized: crop + resize all T frames in one shot ──
    video = video_tensor.float() / 255.0          # (T, C, H, W)
    video = video[:, :, i:i+h, j:j+w]             # spatial crop (single slice)
    video = torch.nn.functional.interpolate(       # single F.interpolate vs 64
        video, size=(384, 384), mode='bilinear', align_corners=False)

    if do_flip:
        video = video.flip(-1)

    if view == "A":
        # All TF functions support (T, C, H, W) — T treated as batch dim
        video = TF.adjust_brightness(video, brightness)
        video = TF.adjust_contrast(video, contrast)
        video = TF.adjust_saturation(video, saturation)
        if abs(hue) > _HUE_EPS:
            video = TF.adjust_hue(video, hue)
    else:
        # gaussian_blur supports (*, C, H, W) via conv2d with groups=C
        video = TF.gaussian_blur(video, kernel_size=23, sigma=1.0)

    video = (video * 255).clamp(0, 255).to(torch.uint8)
    return video


# ── Producer ──────────────────────────────────────────────────────────

def _producer_overlap(processor, batch_size: int, tmp_dir: str,
                       q: queue.Queue, stop_event: threading.Event,
                       clip_limit: int, subset_keys: set,
                       processed_keys: set, num_frames: int,
                       local_data: str = None):
    """Stream clips (HF or local shards), produce two augmented views per clip."""
    produced = 0
    retries = 0
    tar_stop = None

    try:
        pending_bytes = []
        pending_keys = []

        if local_data:
            # Fast path: parallel TAR readers (8 threads, skip processed keys at TAR level)
            clip_q, tar_stop, _reader = iter_clips_parallel(
                local_data, subset_keys=subset_keys, processed_keys=processed_keys)
            while produced < clip_limit and not stop_event.is_set():
                item = clip_q.get(timeout=120)
                if item is None:
                    break
                clip_key, mp4_bytes = item
                if not mp4_bytes:
                    continue
                pending_bytes.append(mp4_bytes)
                pending_keys.append(clip_key)
                if len(pending_bytes) >= batch_size:
                    _decode_augment_enqueue(
                        pending_bytes, pending_keys, tmp_dir, num_frames,
                        processor, q)
                    produced += len(pending_bytes)
                    pending_bytes, pending_keys = [], []
                    if produced >= clip_limit:
                        break
        else:
            # Fallback: sequential HF streaming
            while produced < clip_limit and not stop_event.is_set():
                try:
                    ds = _create_stream(0, local_data=local_data)
                    for example in ds:
                        if stop_event.is_set():
                            break
                        clip_key = get_clip_key(example)
                        if subset_keys and clip_key not in subset_keys:
                            continue
                        if clip_key in processed_keys:
                            continue
                        mp4_data = example.get("mp4", b"")
                        mp4_bytes = mp4_data["bytes"] if isinstance(mp4_data, dict) else mp4_data
                        if not mp4_bytes:
                            continue
                        pending_bytes.append(mp4_bytes)
                        pending_keys.append(clip_key)
                        if len(pending_bytes) >= batch_size:
                            _decode_augment_enqueue(
                                pending_bytes, pending_keys, tmp_dir, num_frames,
                                processor, q)
                            produced += len(pending_bytes)
                            pending_bytes, pending_keys = [], []
                            retries = 0
                            if produced >= clip_limit:
                                break
                    break  # stream exhausted
                except (ConnectionError, TimeoutError, OSError) as e:
                    retries += 1
                    if retries > MAX_STREAM_RETRIES:
                        print(f"  ERROR: stream failed after {MAX_STREAM_RETRIES} retries: {e}")
                        break
                    wait = min(2 ** retries, 60)
                    print(f"  WARN: stream error ({e}), retry {retries}/{MAX_STREAM_RETRIES} in {wait}s")
                    time.sleep(wait)

        # Flush remaining partial batch
        if pending_bytes and not stop_event.is_set():
            _decode_augment_enqueue(
                pending_bytes, pending_keys, tmp_dir, num_frames,
                processor, q)
            produced += len(pending_bytes)

    except Exception as e:
        print(f"  ERROR: unexpected producer error: {e}")
        import traceback
        traceback.print_exc()
    finally:
        if tar_stop:
            tar_stop.set()

    q.put(("done", None, None, None))


def _decode_and_augment_one(mp4_bytes, key, tmp_dir, num_frames):
    """Decode + augment one clip into 2 views. Thread-safe (no shared state).

    Returns (aug_a, aug_b, key) or (None, None, key) on failure.
    """
    # Prevent ATen OpenMP oversubscription: 4 workers × 6 threads = 24
    # = nproc (24 cores). Avoids 4 × 24 = 96 threads (PyTorch #37259)
    torch.set_num_threads(6)
    tensor = decode_video_bytes(mp4_bytes, tmp_dir, key, num_frames)
    if tensor is None:
        return None, None, key
    seed = hash(key) % (2**31)
    aug_a = _augment_clip_consistent(tensor, "A", seed)
    aug_b = _augment_clip_consistent(tensor, "B", seed + 1)
    return aug_a, aug_b, key


# Number of parallel decode+augment workers. cv2/PyAV decode releases GIL,
# torchvision.transforms.functional ops are C++ and release GIL for the heavy
# work (interpolate, gaussian_blur, adjust_*). Safe to thread — each clip uses
# its own tensors with no shared state. NOT ATen threadpool oversubscription:
# these are independent clip-level operations, not intra-op parallelism.
_pcfg = get_pipeline_config()
AUGMENT_WORKERS = _pcfg["streaming"]["augment_workers"]


def _decode_augment_enqueue(pending_bytes, pending_keys, tmp_dir,
                              num_frames, processor, q):
    """Decode + augment batch in parallel, process, enqueue.

    Parallel decode+augment (4 workers, GIL released for C++ ops).
    Sequential processor (normalization — fast, ~5% of total time).
    """
    # 1) Parallel decode + augment (both release GIL for heavy C++ ops)
    with ThreadPoolExecutor(max_workers=AUGMENT_WORKERS) as pool:
        futures = [
            pool.submit(_decode_and_augment_one, b, k, tmp_dir, num_frames)
            for b, k in zip(pending_bytes, pending_keys)
        ]
        results = [f.result() for f in futures]

    views_a = []
    views_b = []
    keys = []
    for aug_a, aug_b, key in results:
        if aug_a is not None:
            views_a.append(aug_a)
            views_b.append(aug_b)
            keys.append(key)

    if not views_a:
        return

    # 2) Sequential processor (normalization — fast after vectorized augment)
    pixels_a = torch.cat([processor(v, return_tensors="pt")["pixel_values_videos"]
                          for v in views_a], dim=0)
    pixels_b = torch.cat([processor(v, return_tensors="pt")["pixel_values_videos"]
                          for v in views_b], dim=0)
    q.put(("batch", pixels_a, pixels_b, keys[:]))


# ── Main ──────────────────────────────────────────────────────────────

def main():
    cleanup_temp()
    parser = argparse.ArgumentParser(
        description="Generate augmented V-JEPA embeddings for True Overlap@K")
    parser.add_argument("--SANITY", action="store_true", help="Process 5 clips only")
    parser.add_argument("--POC", action="store_true", help="10K subset")
    parser.add_argument("--FULL", action="store_true", help="Process all clips")
    parser.add_argument("--batch-size", type=int, default=None)
    add_subset_arg(parser)
    add_local_data_arg(parser)
    add_wandb_args(parser)
    add_gpu_mem_arg(parser)
    # Cache-policy gate (iter11): every destructive delete in this module must route
    # through utils.cache_policy.guarded_delete(path, args.cache_policy, ...).
    # --cache-policy defaults to 1 (keep) so overnight re-runs never destroy cache.
    from utils.cache_policy import add_cache_policy_arg, resolve_cache_policy_interactive
    add_cache_policy_arg(parser)
    args = parser.parse_args()

    # Cache-policy prompt — shells stay thin (CLAUDE.md DELETE PROTECTION).
    args.cache_policy = resolve_cache_policy_interactive(args.cache_policy)

    if not (args.SANITY or args.POC or args.FULL):
        parser.print_help()
        print("\nERROR: Specify --SANITY, --POC, or --FULL")
        sys.exit(1)

    ensure_local_data(args)
    check_gpu()
    # iter15 (2026-05-14): cgroup envelope + OOM watchdog (utils/cgroup_monitor.py)
    print_cgroup_header(prefix="[m05c]")
    start_oom_watchdog(prefix="[m05c]-oom-watchdog")
    device = "cuda"

    output_dir = get_module_output_dir("m05c_true_overlap", args.subset, sanity=args.SANITY, poc=args.POC)
    aug_a_file = output_dir / artifact("overlap_aug_a")
    aug_b_file = output_dir / artifact("overlap_aug_b")
    keys_file = output_dir / artifact("overlap_keys")
    checkpoint_file = output_dir / ".m05c_checkpoint.npz"

    if aug_a_file.exists() and aug_b_file.exists():
        if not check_output_exists([aug_a_file, aug_b_file], "overlap embeddings"):
            print("Using cached augmented embeddings.")
            return

    subset_keys = load_subset(args.subset) if args.subset else set()

    # No deduplication (CLAUDE.md rule #20: using V-JEPA cosine sim to filter
    # eval clips is circular reasoning. Hard mode ±30s exclusion in m06 handles duplicates.)

    if args.SANITY:
        clip_limit = get_sanity_clip_limit("embed")
    elif subset_keys:
        clip_limit = len(subset_keys)
    else:
        clip_limit = get_total_clips(local_data=args.local_data)
        if clip_limit == 0:
            print("FATAL: Cannot determine clip count. Use --subset or --local-data with manifest.json")
            sys.exit(1)

    # Subsample for FULL mode: 30K clips is statistically sufficient for bootstrap CI.
    # Reduces 115K×2 views from ~18h to ~4.7h with torch.compile.
    # Common practice in SSL papers (DINO/BYOL use 50K ImageNet val).
    if args.FULL and not subset_keys:
        overlap_subsample = get_pipeline_config()["eval"]["overlap_subsample"]
        if clip_limit > overlap_subsample:
            print(f"Subsampling: {clip_limit:,} → {overlap_subsample:,} clips "
                  f"(sufficient for bootstrap CI, saves {clip_limit - overlap_subsample:,} clips)")
            clip_limit = overlap_subsample

    batch_size = args.batch_size or compute_batch_sizes(gpu_vram_gb=args.gpu_mem)["vjepa"]
    if args.SANITY:
        batch_size = min(batch_size, 2)

    # Load V-JEPA model
    from transformers import AutoModel, AutoVideoProcessor
    from utils.config import ENCODER_REGISTRY

    model_id = ENCODER_REGISTRY["vjepa"]["model_id"]
    print(f"Loading V-JEPA: {model_id}")
    processor = AutoVideoProcessor.from_pretrained(model_id)
    try:
        import flash_attn  # noqa: F401
    except ImportError:
        print("FATAL: flash-attn not installed.")
        sys.exit(1)
    model = AutoModel.from_pretrained(
        model_id, dtype=torch.float16,  # transformers 5.x: torch_dtype → dtype (#37)
        device_map="auto", attn_implementation="flash_attention_2",
    )
    model.eval()

    # TODO: ToMe (Token Merging, Meta ICLR 2023) for ~2x additional inference speedup.
    # pip install tome && tome.patch.hf(model) — merges similar tokens mid-ViT without retraining.
    # Validated on ViT-L/H (0.2% accuracy drop). Needs validation on ViT-G before enabling.
    # Would bring FULL time from ~4.7h → ~2.4h. Paper-safe (same model, same metric).
    # Reference: github.com/facebookresearch/ToMe, arxiv.org/abs/2210.09461

    model = torch.compile(model)
    print("V-JEPA loaded for augmented inference (torch.compile ON)")

    mode = "SANITY" if args.SANITY else ("POC" if args.POC else "FULL")
    wb_run = init_wandb("m05c", mode, config=vars(args), enabled=not args.no_wandb)

    # Resume from checkpoint (stores interleaved A,B embeddings)
    all_emb_a = []
    all_emb_b = []
    all_keys = []
    processed_keys = set()

    if checkpoint_file.exists():
        data = np.load(checkpoint_file, allow_pickle=True)
        all_emb_a = list(data["emb_a"])
        all_emb_b = list(data["emb_b"])
        all_keys = list(data["keys"])
        processed_keys = set(all_keys)
        print(f"Checkpoint loaded: {len(all_keys):,} clips")

    tmp_base = output_dir / "tmp_m05c"
    tmp_base.mkdir(parents=True, exist_ok=True)
    tmp_dir = tempfile.mkdtemp(dir=tmp_base)

    q = queue.Queue(maxsize=PREFETCH_QUEUE_SIZE)
    stop_event = threading.Event()

    producer = threading.Thread(
        target=_producer_overlap,
        args=(processor, batch_size, tmp_dir, q, stop_event,
              clip_limit, subset_keys, processed_keys, VJEPA_FRAMES_PER_CLIP,
              args.local_data),
        daemon=True,
    )
    producer.start()

    start_time = time.time()
    last_window_count = len(all_keys)
    last_window_time = start_time
    # iter16 (2026-05-21): smoothing=0 → tqdm uses total/elapsed → honest
    # aggregate ETA on bursty workloads (m04d incident: 4.70clip/s headline
    # hid 1.10 clip/s reality). Producer-consumer queue + sub-batched GPU
    # forward = same burst/wait shape as m04d.
    pbar = tqdm(total=clip_limit, initial=len(all_keys),
                desc="m05c true overlap", unit="clip", smoothing=0)
    try:
        while True:
            try:
                msg_type, pixels_a, pixels_b, batch_keys = q.get(timeout=60)
            except queue.Empty:
                print("\nProducer timeout (10 min). Saving checkpoint...")
                break

            if msg_type == "done":
                break

            # Sub-batch via AdaptiveBatchSizer (#47). m05c sees TWO tensors per item
            # (pixels_a, pixels_b — overlapped frame pairs) so VRAM usage is 2× a normal
            # V-JEPA forward → use V-JEPA initial BS halved for safety.
            if 'sizer' not in dir():
                _gpu_cfg = get_pipeline_config()["gpu"]
                sizer = AdaptiveBatchSizer(
                    initial_size=max(1, _gpu_cfg["inference_vjepa_initial_bs"] // 2),
                    min_size=1, max_size=batch_size,
                    memory_cap=_gpu_cfg["gpu_memory_target"])
                print(f"AdaptiveBatchSizer (m05c overlap, paired forward): "
                      f"start={sizer.size}, max={batch_size}, "
                      f"target VRAM={_gpu_cfg['gpu_memory_target']:.0%} (from pipeline.yaml)")
            try:
                emb_a = get_batch_embeddings(model, pixels_a, device)
                emb_b = get_batch_embeddings(model, pixels_b, device)
                sizer.after_batch_success()
            except torch.cuda.OutOfMemoryError:
                cuda_cleanup()
                sizer.on_oom()
                print(f"  OOM on overlap batch ({len(batch_keys)} clips), retrying with sizer={sizer.size}")
                # Fall back to halve-and-retry (preserved): m05c's paired tensors
                # are decoded by the producer; mid-stream resize is non-trivial.
                mid = len(batch_keys) // 2
                emb_a1 = get_batch_embeddings(model, pixels_a[:mid], device)
                emb_b1 = get_batch_embeddings(model, pixels_b[:mid], device)
                cuda_cleanup()
                emb_a2 = get_batch_embeddings(model, pixels_a[mid:], device)
                emb_b2 = get_batch_embeddings(model, pixels_b[mid:], device)
                emb_a = np.concatenate([emb_a1, emb_a2])
                emb_b = np.concatenate([emb_b1, emb_b2])

            for ea, eb, k in zip(emb_a, emb_b, batch_keys):
                all_emb_a.append(ea)
                all_emb_b.append(eb)
                all_keys.append(k)
                processed_keys.add(k)

            pbar.update(len(batch_keys))
            # Windowed throughput (rule #11: never total/elapsed with checkpoint)
            now = time.time()
            window_clips = len(all_keys) - last_window_count
            window_time = now - last_window_time
            throughput = window_clips / window_time if window_time > 0 else 0
            last_window_count = len(all_keys)
            last_window_time = now
            pbar.set_postfix({"rate": f"{throughput:.1f}/s"})

            if len(all_keys) % CHECKPOINT_EVERY < batch_size:
                _save_overlap_checkpoint(all_emb_a, all_emb_b, all_keys, checkpoint_file)

    except KeyboardInterrupt:
        print("\nInterrupted! Saving checkpoint...")
        stop_event.set()
    finally:
        pbar.close()
        stop_event.set()
        _save_overlap_checkpoint(all_emb_a, all_emb_b, all_keys, checkpoint_file)
        producer.join(timeout=10)
        shutil.rmtree(tmp_dir, ignore_errors=True)
        try:
            tmp_base.rmdir()
        except OSError:
            pass

    if not all_emb_a:
        print("ERROR: No embeddings collected.")
        sys.exit(1)

    arr_a = np.stack(all_emb_a).astype(np.float32)
    arr_b = np.stack(all_emb_b).astype(np.float32)

    # Filter to deduped keys only (checkpoint may contain extra clips from prior runs)
    if subset_keys and len(all_keys) > len(subset_keys):
        keep = np.array([k in subset_keys for k in all_keys])
        n_before = len(all_keys)
        arr_a = arr_a[keep]
        arr_b = arr_b[keep]
        all_keys = [k for k, m in zip(all_keys, keep) if m]
        print(f"  Filtered: {n_before:,} → {len(all_keys):,} (removed {n_before - len(all_keys):,} non-deduped)")

    # Defensive shape check (incident 2026-04-26 — see utils.config).
    # NOTE: m05c filters non-deduped clips just above (lines 477-483) so the
    # post-filter row-count is what should match --subset.
    verify_npy_matches_subset(arr_a, args.subset, label="m05c overlap_augA")
    verify_npy_matches_subset(arr_b, args.subset, label="m05c overlap_augB")

    np.save(aug_a_file, arr_a)
    np.save(aug_b_file, arr_b)
    np.save(keys_file, np.array(all_keys, dtype=object))

    # iter11 META-fix: gate checkpoint cleanup through --cache-policy (default=1/keep).
    from utils.cache_policy import guarded_delete
    guarded_delete(checkpoint_file, args.cache_policy,
                   label="m05c true_overlap checkpoint")

    print(f"\nSaved: {aug_a_file} ({arr_a.shape})")
    print(f"Saved: {aug_b_file} ({arr_b.shape})")
    print(f"Saved: {keys_file} ({len(all_keys)} keys)")
    print("\nNext: python -u src/m06_faiss_metrics.py --true-overlap --FULL --subset data/subset_10k_local/subset_10k.json")

    log_metrics(wb_run, {"total_clips": len(all_keys), "embedding_dim": arr_a.shape[1]})
    log_artifact(wb_run, "overlap_augA", str(aug_a_file))
    log_artifact(wb_run, "overlap_augB", str(aug_b_file))
    finish_wandb(wb_run)

    # Force exit: torch.compile + CUDA atexit cleanup deadlocks on futex_wait_queue
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(0)


def _save_overlap_checkpoint(emb_a, emb_b, keys, checkpoint_file):
    """Save overlap checkpoint (both views + keys)."""
    if not emb_a:
        return
    checkpoint_file.parent.mkdir(parents=True, exist_ok=True)
    tmp = checkpoint_file.with_name(checkpoint_file.stem + "_tmp.npz")
    np.savez(tmp,
             emb_a=np.stack(emb_a).astype(np.float32),
             emb_b=np.stack(emb_b).astype(np.float32),
             keys=np.array(keys, dtype=object))
    os.replace(tmp, checkpoint_file)


if __name__ == "__main__":
    main()
