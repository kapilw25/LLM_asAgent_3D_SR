# Future-Frame Prediction — Reference Pack (V-JEPA 2.1)

Known-good reference for wiring up `m12d_future_mse.py` (future-frame MSE) / `m12e_predictor_temporal.py`
(predictor-temporal) from the FactorJEPA codebase. The numbers here come from a clean GPU eval run.

## What's in here
| path | what |
|---|---|
| `clips/` | 10 WalkIndia eval-domain MP4 clips (~5 MB) for a small smoke |
| `expected/frozen_2B_aggregate_mse.json` | gold frozen reference (ViT-G, 2B) |
| `expected/frozen_1B_aggregate_mse.json` | frozen reference (ViT-g, 1B — lighter for Colab) |
| `config/vjepa2_1_vitG_2B.yaml` | 2B model + predictor config |
| `config/vjepa2_1_vitg_1B.yaml` | 1B model + predictor config |
| `eval_10k_test_split.json` | the 1825-clip test set (clip keys) for the full-set aggregate |

> ⚠️ The `clips/` are the m11 factor **verify** clips, NOT the exact 1825-clip test split (those decode
> on-the-fly from TARs). Use them to confirm the forward **runs** and gives sane per-clip L1 — not to
> reproduce the aggregate exactly. For the exact aggregate, run over `eval_10k_test_split.json`.

## You download separately (too big to bundle — base ckpt holds encoder + predictor)
- 2B ViT-G (30 GB): `https://dl.fbaipublicfiles.com/vjepa2/vjepa2_1_vitG_384.pt`
- 1B ViT-g (15 GB): `https://dl.fbaipublicfiles.com/vjepa2/vjepa2_1_vitg_384.pt`  ← lighter for Colab

## Expected outputs (the known-good numbers)
| backbone | base ckpt | frozen future-MSE (mean) | 95% CI half | std | n | num_frames |
|---|---|---|---|---|---|---|
| 2B ViT-G | vjepa2_1_vitG_384.pt | **0.557351** | ±0.00085 | 0.0184 | 1825 | 16 |
| 1B ViT-g | vjepa2_1_vitg_384.pt | **0.636863** | ±0.00125 | 0.0271 | 1825 | 16 |

Deterministic: the eval seeds torch (`seed=99`, `pipeline.yaml > probe.seed`) + a `no_grad` forward, so the
aggregate reproduces bit-identically given the same clips/ckpt/seed. Per-clip L1 ≈ mean ± std → for a correct
forward on eval-domain clips expect roughly **0.52–0.59 (2B)** / **0.61–0.66 (1B)**.

## Minimal smoke (Colab — load + forward a batch)
```python
import torch
from utils.predictor_eval import load_encoder_predictor, build_mask_gen, masked_predict_l1

enc, pred, embed_dim = load_encoder_predictor("vjepa2_1_vitG_384.pt", num_frames=16)
enc.eval(); pred.eval()                      # frozen — no grad
mgen = build_mask_gen(num_frames=16)         # V-JEPA 2.1 small-block mask defaults

# pixel: (B, C=3, T=16, H=384, W=384), float, ImageNet-normalized, on the GPU
m_enc, m_pred = mgen(pixel.shape[0])
per_clip_l1, out, h_target = masked_predict_l1(enc, pred, pixel, m_enc, m_pred)
print(per_clip_l1.mean().item())             # ≈ 0.557 (2B) over enough eval clips
```

## Full-pipeline run (matches the eval exactly)
```bash
python -u src/m12d_future_mse.py --FULL --stage forward --variant vjepa_2_1_frozen \
  --encoder-ckpt checkpoints/vjepa2_1_vitG_384.pt \
  --action-probe-root <out>/probe_action \
  --local-data <data>/eval_10k_local \
  --output-root <out>/probe_future_mse --cache-policy 1
# → writes probe_future_mse/vjepa_2_1_frozen/aggregate_mse.json ; compare mse_mean to the table
```

## How loading works (don't reinvent it)
- `utils/predictor_eval.load_encoder_predictor(ckpt_path, num_frames) -> (encoder, predictor, embed_dim)`
  resolves BOTH the encoder + predictor state dicts from the ckpt. The base ckpt has both.
- Fine-tuned arm → use that arm's `*_ckpt_best.pt` (~8 GB, tuned encoder+predictor). The `student_encoder.pt`
  (~3.8 GB) is **ENCODER-ONLY (no predictor)** → it will fail for future-frame.
- `get_vit_predictor_2_1` / `get_apply_masks` / `get_mask_generator` (+ `get_vit_by_arch`) ALL come from the
  one shim `src/utils/vjepa2_imports.py` → vendored `deps/vjepa2`. Never `from models…` directly.

## Predictor config (from the yaml — V-JEPA 2.1)
`pred_depth 24` · `pred_embed_dim 384` · `pred_num_heads 12` · `num_mask_tokens 2` ·
`predict_all: true` (DENSE loss — L1 on ALL tokens, not just masked: the 2.1 difference) ·
`n_output_distillation 4` (layers [11,23,37,47]) · `patch 16` · `tubelet 2` · `crop 384`.

## Gotchas (we hit these on a fresh node — save yourself the debug)
1. `m12d` FAILs-loud without `--local-data` (clip source) AND `--action-probe-root` (test split lives in
   `action_labels.json`). Both required.
2. Use the BASE ckpt or `*_ckpt_best.pt` — **not** `student_encoder.pt` (no predictor → shape mismatch).
3. `predict_all: true` → the L1 is over ALL tokens, not just masked. Keep it or your numbers won't match.
4. Input must be ImageNet-normalized, 16 frames, 384 crop, tubelet 2 — same as the encoder's training.
